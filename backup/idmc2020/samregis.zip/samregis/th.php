<?php

$text01 = "กรอกข้อมูลลงทะเบียน";
$text02 = "หลักฐานการชำระเงิน";
$text03 = "ยืนยันการส่งข้อมูล";
$text04 = "ลงทะเบียนเรียบร้อยแล้ว";
$text05 = "ข้อมูลลงทะเบียน";
$text06 = "แก้ไขชื่อผู้สมัคร";

$fname = "ชื่อ";
$lname = "นามสกุล";
$christ = "ชื่อคริสตจักร";
$email = "Email ของคุณ";
$emailconfirm = "ยืนยัน Email ของคุณ";
$emailExample = "example@email.com";
$phone = "เบอร์โทรศัพท์";
$phoneExample = "+66990001122";
$upload = "อัพโหลดไฟล์";
$noteupload = "ขนาดไฟล์ไม่เกิน 2 MB.";
$noteuploadNotice = "ขนาดไฟล์ใหญ่เกินไป!!";
$refName = "รหัสอ้างอิง";
$statusText1 = "สถานะลงทะเบียน";
$statusText2 = "สถานะรับของที่ระลึก";

$textuser = "ชื่อผู้ใช้งาน";
$textpass = "รหัสผ่าน";
$textlogin = "เข้าสู่ระบบ";
$textSetting = "ตั้งค่าระบบ";
$notiPass = "ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง";

$textDashboard = "ภาพรวมข้อมูล";
$textRegister = "ผู้ลงทะเบียน";
$textRegis = "ลงทะเบียน";
$textReport = "รายงาน";
$textLogout = "ออกจากระบบ";
$textReceive = "รับของที่ระลึก";

$textMainbtn1 = "ผู้สมัครทั้งหมด";
$textMainbtn2 = "ผู้สมัครที่แนบสลิป";
$textMainbtn3 = "ผู้สมัครที่ไม่แนบสลิป";
$textMainbtn4 = "ผู้สมัครที่อนุมัติแล้ว";
$textMainbtn5 = "ผู้สมัครที่รอตรวจสอบ";
$textMainbtn6 = "Approved";
$textMainbtn7 = "Received";

$backtohome = "กลับหน้าหลัก";
$AttachSlip = "Attach slip";
$AttachSliptext = "Attach slip";
$NotAttachSliptext = "ไม่มีไฟล์แนบ";

$textsubmitedit = "แก้ไข";
$textsubmitdel = "ลบข้อมูล";
$textsubmitappr = "อนุมัติ";
$textDel = "คุณแน่ใจที่จะลบข้อมูลนี้??";
$textAppr = "คุณแน่ใจที่จะอนุมัติข้อมูลนี้??";

$emailnotmatch = " Email ของคุณไม่ตรงกัน";
$sendmailagain = "ส่ง Email อีกครั้ง";

$search_text = "ค้นหา";
$pleaseinput = "กรุณาใส่กรอกเลขอ้างอิง";

$textConfirm = "ข้าพเจ้ายินยอมให้ <span style='color: blue; text-decoration: underline;'>www.samregis.com</span> จัดเก็บและประมวลผลข้อมูลอันเป็นข้อมูลส่วนบุคคลของข้าพเจ้าทั้งหมดนี้ เพื่อใช้ประโยชน์ในการเข้าร่วมกิจกรรม <strong>idmc 2020</strong> และ/หรือให้ผู้ดูแลข้อมูลสามารถส่งมอบข้อมูลทั้งหมดนี้ของข้าพเจ้าให้คณะผู้จัดกิจกรรม <strong>idmc 2020</strong> เพื่อประโยชน์ในการตรวจสอบและประมวลผลข้อมูลรวมทั้งเพื่อแสดงตนของข้าพเจ้าในการเข้าร่วมกิจกรรมร่วมกิจกรรมนี้ โดยผู้จัดเก็บและประมวลผลข้อมูลจะทำการลบและทำลายข้อมูลนี้ทันทีที่เสร็จสิ้นการประมวลผลและใช้ประโยชน์ข้อมูลโดยไม่จำเป็นต้องแจ้งให้ข้าพเจ้าทราบ และห้ามมิให้ผู้จัดเก็บและประมวลผลข้อมูลส่งมอบข้อมูลทั้งหมดนี้ของข้าพเจ้าเพื่อการอื่นนอกจากที่กล่าวมาข้างต้นโดยไม่ได้รับความยินยอมจากข้าพเจ้า";

$textAccept = "ยินยอม";
$textBtnOk = "ตกลง";
$textBtncancel = "ยกเลิก";


?>