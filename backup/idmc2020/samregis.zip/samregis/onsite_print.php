<?php
include 'config.php';

$lang = $_GET['lang'];
if ($lang=="") {
	$lang = $_POST['lang'];
}
if ($lang=='en') {
	include 'en.php';
	$lang = 'en';
}else{
	include 'th.php';
	$lang = 'th';
}
$page = basename($_SERVER['PHP_SELF']);


$c_id = $_GET['c_id'];


$cmd3 = " SELECT * from customer_db where c_id='$c_id' ";
$result3 = mysqli_query($conn,$cmd3);
while ($rs3 = mysqli_fetch_array($result3)) {

  $firstname = trim($rs3['fname']);
  $lastname = trim($rs3['lname']);
  $christian = trim($rs3['christian']);
  $phoneNum = trim($rs3['phone']);
  $emailvalue = trim($rs3['email']);
  $ref_id = trim($rs3['ref_id']);
  $pic1 = trim($rs3['pic1']);
  $pic2 = trim($rs3['pic2']);
  $ref_id = trim($rs3['ref_id']);

}







$cmd3 = " SELECT * from setting where site_id='$Site' ";
$result3 = mysqli_query($conn,$cmd3);
while ($rs3 = mysqli_fetch_array($result3)) {

	$subject = trim($rs3['subject']);

	if ($subject == "logo") {
		$logo = trim($rs3['value']);
	}

	if ($subject == "project_name") {
		$project_name = trim($rs3['value']);
	}


} 



?>
<!DOCTYPE html>
<html>
<head>
	<title><?=$Title?></title>
</head>
<body>
<table width="219">
	<tr align="center">
		<td>
			<img src="images/logo/<?=$logo?>" width="60"><br>
			<?=$project_name?>
		</td>
	</tr>
	<tr align="center">
		<td>
			<img src="images/qrcode/<?=$pic2?>" width="100%"><br>
			หมายเลขอ้างอิง : <?=$ref_id?>
		</td>
	</tr>
	<tr align="center">
		<td>
			<?=$firstname?> <?=$lastname?>
		</td>
	</tr>
</table>

<script type="text/javascript">
 window.print();

</script> 
</body>
</html>