<?php

$text01 = "Peronal Infomation";
$text02 = "Payment Slip";
$text03 = "Submit Summary";
$text04 = "Register Successfully";
$text05 = "Peronal Infomation";
$text06 = "Peronal Infomation Edit";

$fname = "First Name";
$lname = "Last Name";
$christ = "The Church of Christ";
$email = "Your Email";
$emailconfirm = "Your Email Confirm";
$emailExample = "example@email.com";
$phone = "Phone Number";
$phoneExample = "+66990001122";
$upload = "Upload a file";
$noteupload = "Maximum Upload File Size 2 MB.";
$noteuploadNotice = "File Is Too Large!!";
$refName = "Ref ID";
$statusText1 = "Registed";
$statusText2 = "Received";

$textuser = "Username";
$textpass = "Password";
$textlogin = "Login";
$notiPass = "username or password is incorrect";

$textDashboard = "Dashboard";
$textRegister = "Register";
$textRegis = "Registration";
$textReport = "Report";
$textLogout = "Logout";
$textSetting = "Setting";
$textReceive = "Souvenir";

$textMainbtn1 = "All Register";
$textMainbtn2 = "Attach slip";
$textMainbtn3 = "Not attached slip";
$textMainbtn4 = "Approved";
$textMainbtn5 = "Waiting Approve";
$textMainbtn6 = "Approved";
$textMainbtn7 = "Received";

$backtohome = "Back to home";
$AttachSlip = "Attach slip";
$AttachSliptext = "Attach slip";
$NotAttachSliptext = "Not attached slip";


$textsubmitedit = "Edit";
$textsubmitdel = "Delete";
$textsubmitappr = "Approve";
$textDel = "Are you sure to delete this data??";
$textAppr = "Are you sure to approve this data??";

$emailnotmatch = "Your Email Not Match";
$sendmailagain = "Send Email ";

$search_text = "Search";
$pleaseinput = "Please input the reference number";

$textConfirm = "I consent to <span style='color: blue; text-decoration: underline;'>www.samregis.com</span> to collect,  process and use,  my personal data for the purpose of <strong>IDMC THAILAND 2020</strong> participation and/or forward to all of my data to the <strong>IDMC THAILAND 2020</strong> event organizers for the purpose of verifying and processing information, including to show myself in participating the event. The data collector and data processor will delete and destroy this data as soon as the data processing is completed and utilized without the need to notify me and the data collector and data processors are prohibited from delivering all of this data for any purpose other than in the manner as identified above without my consent.";

$textAccept = "Accept";
$textBtnOk = "OK";
$textBtncancel = "Cancel";

?>