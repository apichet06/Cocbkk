 <!-- <div id="form-total">  -->
			 <nav class="navbar navbar-expand-lg navbar-light bg-light" style="border-radius:  10px 10px 0px 0px;">
			  <a class="navbar-brand" href="#">
			  	<img src="images/logo/<?=$logo?>" width="60">
			  </a>
			  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			    <span class="navbar-toggler-icon"></span>
			  </button>
			  <div class="collapse navbar-collapse" id="navbarNav">
			    <ul class="navbar-nav">
			      <!-- <li class="nav-item <?=$mainSelect?> ">
			        <a class="nav-link" href="main.php"><?=$textDashboard?></a>
			      </li> -->
			      <li class="nav-item <?=$registerSelect?>">
			        <a class="nav-link" href="register.php"><?=$textDashboard?></a>
			      </li>
			      <li class="nav-item <?=$settingSelect?>">
			        <a class="nav-link" href="setting.php"><?=$textSetting?></a>
			      </li>
			      <!-- <li class="nav-item <?=$reportSelect?>">
			        <a class="nav-link" href="report.php"><?=$textReport?></a>
			      </li> -->
			      <li class="nav-item">
			        <a class="nav-link" href="admin"><?=$textLogout?></a>
			      </li>
			    </ul>
			  </div>
			</nav>
		        <!-- </div> -->